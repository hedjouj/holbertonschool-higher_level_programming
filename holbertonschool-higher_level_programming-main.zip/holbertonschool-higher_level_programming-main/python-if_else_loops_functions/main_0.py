#!/usr/bin/python3
from uppercase import uppercase

uppercase("Holberton")  # Call the function with the desired input