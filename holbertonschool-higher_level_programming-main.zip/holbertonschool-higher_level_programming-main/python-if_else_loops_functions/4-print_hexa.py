#!/usr/bin/python3
for i in range(99):
    print(f"{i} = 0x{i:x}".format(i, i))
