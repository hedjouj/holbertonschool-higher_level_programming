Python - Test-driven development
🔧 Qu’est-ce que le Test-Driven Development (TDD) ?
TDD veut dire développement piloté par les tests.

C’est une méthode de programmation dans laquelle tu écris d’abord les tests, avant d’écrire le code.

🧠 Pourquoi faire ça ?
Parce que :

Tu sais exactement ce que ton code doit faire

Tu peux vérifier automatiquement si ton code fonctionne

Tu évites les bugs

Ton code est plus fiable et mieux organisé