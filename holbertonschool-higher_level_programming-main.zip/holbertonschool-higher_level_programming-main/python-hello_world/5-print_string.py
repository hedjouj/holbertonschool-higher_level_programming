#!/usr/bin/python3
str = "Holberton School"
print(f"{str}{str}{str}\n{str[:9]}")
