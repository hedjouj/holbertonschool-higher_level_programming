Python - Data Structures: Lists, Tuples

